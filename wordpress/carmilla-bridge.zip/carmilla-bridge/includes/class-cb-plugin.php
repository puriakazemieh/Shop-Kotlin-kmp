<?php
/**
 * Plugin bootstrap: registers REST routes, wires JWT Bearer authentication,
 * and exposes permission callbacks used across controllers.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CB_Plugin {

	private static $instance = null;

	/** Cache of the user resolved from the Bearer token for the current request. */
	private static $bearer_user = null;

	public static function instance(): CB_Plugin {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		CB_CPT::boot();
		$manifest_controller = new CB_Manifest_Controller();
		$integrations_controller = new CB_Integrations_Controller();
		$integrations_controller->init();
		CB_Mail_Adapter::init();
		CB_Message_Queue::init();
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		// Apply the manifest policy before any controller callback executes.
		add_filter( 'rest_pre_dispatch', array( 'CB_Manifest_Controller', 'guard_rest_request' ), 10, 3 );
		add_action( 'admin_menu', array( $manifest_controller, 'register_admin_page' ) );
		add_action( 'admin_post_cb_save_manifest_settings', array( $manifest_controller, 'save_admin_settings' ) );
		// Let a valid Bearer token authenticate normal WP REST requests too.
		add_filter( 'determine_current_user', array( $this, 'authenticate_bearer' ), 20 );
		// Keep product Q&A comments out of the normal comment feed/counts.
		add_filter( 'comments_clauses', array( 'CB_Interaction_Controller', 'hide_qna_clauses' ) );
		// A few app endpoints use a host-root path (/api/users/me, /api/addresses)
		// that would fall outside /wp-json/carmilla/v1/. Alias them to the REST
		// routes so the app needs no client-side change.
		add_action( 'parse_request', array( $this, 'maybe_root_alias' ) );
		// Allow the app (web/desktop build served from another origin) to call the
		// REST API cross-origin. Filterable via `cb_enable_cors` (default: on).
		add_action( 'rest_api_init', array( $this, 'enable_cors' ), 15 );
	}

	/**
	 * Send permissive CORS headers for our REST API so a Compose-Web / desktop
	 * build hosted on a different origin can read and manage the site. Echoes the
	 * request Origin (with credentials) so JWT Authorization headers pass. This is
	 * expected for a headless "bridge" plugin; disable with:
	 *   add_filter( 'cb_enable_cors', '__return_false' );
	 */
	public function enable_cors(): void {
		if ( ! apply_filters( 'cb_enable_cors', true ) ) {
			return;
		}
		remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );
		add_filter( 'rest_pre_serve_request', function ( $served ) {
			$origin = get_http_origin();
			$allowed = false;
			if ( $origin ) {
				$origin_clean = untrailingslashit( $origin );
				$allowed_origins = apply_filters( 'cb_allowed_origins', array(
					untrailingslashit( get_site_url() ),
					'http://localhost:8080',
					'http://localhost:8081',
				) );
				if ( defined( 'CB_ALLOWED_ORIGINS' ) ) {
					$env_origins = array_map( 'trim', explode( ',', CB_ALLOWED_ORIGINS ) );
					$allowed_origins = array_merge( $allowed_origins, $env_origins );
				}
				if ( in_array( $origin_clean, $allowed_origins, true ) ) {
					$allowed = true;
					header( 'Access-Control-Allow-Origin: ' . esc_url_raw( $origin_clean ) );
					header( 'Access-Control-Allow-Credentials: true' );
				}
			}
			
			if ( ! $allowed ) {
				// Do not allow credentials for unapproved origins.
				header( 'Access-Control-Allow-Origin: null' );
			}
			
			header( 'Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS' );
			header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce' );
			header( 'Vary: Origin', false );
			// Preflight: answer OPTIONS immediately with the headers above.
			if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'OPTIONS' === strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) ) {
				status_header( 204 );
				exit;
			}
			return $served;
		} );
	}

	/**
	 * Dispatch root-level /api/users/me and /api/addresses* to the matching REST
	 * route via rest_do_request, then emit the JSON and stop. No-op for any other
	 * URL, so normal WordPress routing is untouched.
	 */
	public function maybe_root_alias(): void {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ) : '';
		$uri = '/' . ltrim( untrailingslashit( $uri ), '/' );
		$root_paths = array( '/api/users/me', '/api/addresses', '/api/favorites', '/api/recently-viewed' );
		$match = false;
		foreach ( $root_paths as $rp ) {
			if ( $uri === $rp || strpos( $uri, $rp . '/' ) === 0 ) {
				$match = true;
				break;
			}
		}
		if ( ! $match ) {
			return;
		}

		// Telemetry and Deprecation for legacy root aliases
		error_log( 'Carmilla Bridge Legacy Alias Usage: ' . $uri );
		header( 'X-Carmilla-Deprecated: root-alias' );
		header( 'Warning: 299 - "Legacy root alias is deprecated and will be removed in the next client cycle"' );

		$method  = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : 'GET';
		$request = new WP_REST_Request( $method, '/' . CB_REST_NAMESPACE . $uri );
		foreach ( (array) $_GET as $k => $v ) {
			$request->set_param( sanitize_text_field( (string) $k ), $v );
		}
		$body = file_get_contents( 'php://input' );
		if ( $body !== '' && $body !== false ) {
			$request->set_body( $body );
			$request->set_header( 'Content-Type', 'application/json' );
		}

		$response = rest_do_request( $request );
		$server   = rest_get_server();
		$data     = $server->response_to_data( $response, false );

		status_header( $response->get_status() );
		header( 'Content-Type: application/json; charset=utf-8' );
		echo wp_json_encode( $data );
		exit;
	}

	public function register_routes(): void {
		( new CB_Manifest_Controller() )->register_routes();
		( new CB_Auth_Controller() )->register_routes();
		( new CB_Catalog_Controller() )->register_routes();
		( new CB_Blog_Controller() )->register_routes();
		( new CB_Media_Controller() )->register_routes();
		// Phase 2: full commerce.
		( new CB_Cart_Controller() )->register_routes();
		( new CB_Order_Controller() )->register_routes();
		( new CB_Payment_Controller() )->register_routes();
		( new CB_Account_Controller() )->register_routes();
		( new CB_Interaction_Controller() )->register_routes();
		// Phase 3 & 4: LMS, Clinic, Psych tests (Disabled by default until Phase 13/14).
		if ( apply_filters( 'cb_enable_health_lms', false ) ) {
			( new CB_Academy_Controller() )->register_routes();
			( new CB_Clinic_Controller() )->register_routes();
			( new CB_Psychtest_Controller() )->register_routes();
			( new CB_Course_Request_Controller() )->register_routes();
			( new CB_Admin_Clinic_Controller() )->register_routes();
		}
		( new CB_Extras_Controller() )->register_routes();
		( new CB_Support_Controller() )->register_routes();
		( new CB_Bundle_Controller() )->register_routes();
		( new CB_Story_Controller() )->register_routes();
		// Phase 6: admin panel.
		( new CB_Admin_Controller() )->register_routes();
		( new CB_Admin_Content_Controller() )->register_routes();
		( new CB_Admin_Product_Controller() )->register_routes();
		( new CB_Admin_B2B_Controller() )->register_routes();
		( new CB_Admin_Bundle_Controller() )->register_routes();
	}

	/**
	 * Resolve the WP user id from an Authorization: Bearer <jwt> header.
	 * Runs on determine_current_user so downstream capability checks work.
	 */
	public function authenticate_bearer( $user_id ) {
		if ( ! empty( $user_id ) ) {
			return $user_id; // Already authenticated (cookie/app-password).
		}
		$token = self::bearer_token();
		if ( ! $token ) {
			return $user_id;
		}
		$payload = CB_JWT::decode( $token );
		if ( ! $payload || ( $payload['typ'] ?? '' ) !== 'access' ) {
			return $user_id;
		}
		$uid = (int) ( $payload['uid'] ?? 0 );
		if ( $uid > 0 && get_user_by( 'id', $uid ) ) {
			self::$bearer_user = $uid;
			return $uid;
		}
		return $user_id;
	}

	// ---- static accessors used by controllers -------------------------------

	public static function bearer_token() {
		$header = '';
		if ( isset( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			$header = $_SERVER['HTTP_AUTHORIZATION'];
		} elseif ( isset( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
			$header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
		} elseif ( function_exists( 'getallheaders' ) ) {
			$all = getallheaders();
			foreach ( $all as $k => $v ) {
				if ( strtolower( $k ) === 'authorization' ) {
					$header = $v;
					break;
				}
			}
		}
		if ( $header && stripos( $header, 'Bearer ' ) === 0 ) {
			return trim( substr( $header, 7 ) );
		}
		return null;
	}

	/**
	 * The WP_User for the current request (from Bearer or logged-in cookie), or null.
	 */
	public static function current_user( $request = null ) {
		$id = get_current_user_id();
		if ( $id ) {
			return get_user_by( 'id', $id );
		}
		return null;
	}

	// ---- permission callbacks ----------------------------------------------

	public static function require_login(): bool {
		return is_user_logged_in();
	}

	/**
	 * Write access = Administrator or Shop Manager (edit_others_posts / manage_woocommerce).
	 */
	public static function require_admin(): bool {
		return current_user_can( 'edit_others_posts' ) || current_user_can( 'manage_woocommerce' );
	}

	/**
	 * Write access to health records (clinic, psychtests) = Administrator only.
	 * Shop Managers should not see patient files or test results.
	 */
	public static function require_health_admin(): bool {
		return current_user_can( 'manage_options' );
	}
}
