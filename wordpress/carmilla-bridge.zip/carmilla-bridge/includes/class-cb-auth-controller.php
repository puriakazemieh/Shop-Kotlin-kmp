<?php
/**
 * Auth endpoints mirroring the Spring AuthController, backed by WordPress users.
 *   POST api/auth/login       { username, password } -> AuthResponse
 *   POST api/auth/register    { email?, mobile?, password } -> AuthResponse
 *   POST api/auth/refresh     { refreshToken } -> RefreshTokenResponse
 *   GET  api/users/me         (Bearer) -> UserResponse
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once __DIR__ . '/class-cb-identity-supported-writer.php';
require_once __DIR__ . '/class-cb-otp-atomic-consumer.php';
require_once __DIR__ . '/class-cb-reset-atomic-consumer.php';

class CB_Auth_Controller {

	public function register_routes(): void {
		$ns = CB_REST_NAMESPACE;

		register_rest_route( $ns, '/api/auth/login', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'login' ),
			'permission_callback' => '__return_true',
		) );

		register_rest_route( $ns, '/api/auth/register', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'register' ),
			'permission_callback' => '__return_true',
		) );

		register_rest_route( $ns, '/api/auth/refresh', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'refresh' ),
			'permission_callback' => '__return_true',
		) );

		// NOTE: GET/PATCH /api/users/me is owned by CB_Account_Controller
		// (ProfileResponse), which is what the app's ProfileApi expects.

		// Password reset + OTP login (all public).
		foreach ( array(
			'forgot-password'          => 'forgot_password',
			'send-login-otp'           => 'send_login_otp',
			'login-with-otp'           => 'login_with_otp',
			'reset-password'           => 'reset_password',
			'reset-password-with-otp'  => 'reset_password_with_otp',
		) as $path => $method ) {
			register_rest_route( $ns, '/api/auth/' . $path, array(
				'methods'             => 'POST',
				'callback'            => array( $this, $method ),
				'permission_callback' => '__return_true',
			) );
		}
	}

	// ---- OTP + password reset ----------------------------------------------

	/** Find a user by their stored mobile (cb_mobile meta or login). */
	private static function user_by_mobile( string $mobile ) {
		$mobile = trim( $mobile );
		if ( $mobile === '' ) {
			return null;
		}
		$identity = ( new CB_Identity_Supported_Writer() )->lookup( $mobile );
		return $identity['status'] === 'UNIQUE' ? get_user_by( 'id', $identity['user_id'] ) : null;
	}

	/**
	 * Generate + "send" a 6-digit OTP for a mobile with purpose, cooldown, and hash.
	 */
	private function issue_otp( string $mobile, string $purpose ): string {
		// Atomic consumption relies on database-backed transients.  An external
		// object cache has different delete/read semantics, so never send a code
		// that the verification path would be unable to consume safely.
		if ( wp_using_ext_object_cache() ) {
			throw new RuntimeException( 'ورود با کد تأیید موقتاً در دسترس نیست.' );
		}
		$hash_key = md5( $mobile . '_' . $purpose );

		if ( get_transient( 'cb_otp_cooldown_' . $hash_key ) ) {
			throw new Exception( 'لطفاً یک دقیقه صبر کنید.' );
		}

		$code = (string) wp_rand( 100000, 999999 );
		$hashed = wp_hash_password( $code );

		set_transient( 'cb_otp_' . $hash_key, $hashed, 3 * MINUTE_IN_SECONDS );
		set_transient( 'cb_otp_cooldown_' . $hash_key, '1', MINUTE_IN_SECONDS );
		delete_transient( 'cb_otp_attempts_' . $hash_key );

		// Allow override via filter
		$override = apply_filters( 'cb_send_otp_override', null, $mobile, $code, $purpose );
		if ( $override !== null ) {
			if ( is_wp_error( $override ) ) {
				delete_transient( 'cb_otp_cooldown_' . $hash_key );
				delete_transient( 'cb_otp_' . $hash_key );
				error_log( 'Carmilla OTP dispatch unavailable (override).' );
				throw new RuntimeException( 'ارسال کد تأیید موقتاً در دسترس نیست.' );
			}
		} else {
			// Build message using template engine if available
			$template = get_option('carmilla_message_settings', [])['sms_otp_template'] ?? 'کد تایید شما: {{code}}';
			$message = class_exists('CB_Template_Engine') ? CB_Template_Engine::render($template, ['code' => $code]) : "کد تایید شما: $code";
			
			$result = CB_SMS_HTTP_Adapter::send($mobile, $message);
			if ( is_wp_error( $result ) ) {
				// Don't set cooldown if sending failed so they can retry immediately
				delete_transient( 'cb_otp_cooldown_' . $hash_key );
				delete_transient( 'cb_otp_' . $hash_key );
				error_log( 'Carmilla OTP dispatch unavailable (SMS adapter).' );
				throw new RuntimeException( 'ارسال کد تأیید موقتاً در دسترس نیست.' );
			}
		}

		do_action( 'cb_send_otp', $mobile, $code, $purpose ); // legacy hook
		return $code;
	}

	private function verify_otp( string $mobile, string $code, string $purpose ): bool {
		$hash_key = md5( $mobile . '_' . $purpose );
		if ( wp_using_ext_object_cache() || ! preg_match( '/\A[0-9]{6}\z/', trim( $code ) ) ) {
			return false;
		}

		$attempts = (int) get_transient( 'cb_otp_attempts_' . $hash_key );
		if ( $attempts >= 3 ) {
			delete_transient( 'cb_otp_' . $hash_key );
			delete_transient( 'cb_otp_attempts_' . $hash_key );
			return false;
		}

		if ( ( new CB_OTP_Atomic_Consumer() )->consume( $mobile, $purpose, $code ) ) {
			delete_transient( 'cb_otp_attempts_' . $hash_key );
			return true;
		}

		// Attempt counting is advisory only.  It is deliberately not used to
		// authorize the code: authorization always goes through the atomic
		// database delete above.  Do not create an attempt record for expiry,
		// database failure, or a concurrent winning request.
		$stored = get_transient( 'cb_otp_' . $hash_key );
		if ( is_string( $stored ) && $stored !== '' && ! wp_check_password( trim( $code ), $stored ) ) {
			set_transient( 'cb_otp_attempts_' . $hash_key, $attempts + 1, 3 * MINUTE_IN_SECONDS );
		}
		return false;
	}

	public function send_login_otp( WP_REST_Request $request ) {
		$mobile = trim( (string) $request->get_param( 'mobile' ) );
		if ( $mobile === '' ) {
			return cb_error( 'شماره موبایل الزامی است.', 400, 'VALIDATION' );
		}
		if ( wp_using_ext_object_cache() ) {
			return cb_error( 'ورود با کد تأیید موقتاً در دسترس نیست.', 503, 'OTP_UNAVAILABLE' );
		}
		try {
			$this->issue_otp( $mobile, 'login' );
		} catch ( RuntimeException $e ) {
			return cb_error( $e->getMessage(), 503, 'OTP_UNAVAILABLE' );
		} catch ( Exception $e ) {
			return cb_error( $e->getMessage(), 429, 'RATE_LIMIT' );
		}
		return cb_response( array( 'sent' => true ), 200 );
	}

	public function login_with_otp( WP_REST_Request $request ) {
		$mobile = trim( (string) $request->get_param( 'mobile' ) );
		$code   = (string) $request->get_param( 'otpCode' );
		if ( ! $this->verify_otp( $mobile, $code, 'login' ) ) {
			return cb_error( 'کد تأیید نادرست یا منقضی است.', 401, 'BAD_OTP' );
		}
		$user = self::user_by_mobile( $mobile );
		if ( ! $user ) {
			// First OTP login registers the mobile-only account.
			$uid = ( new CB_Identity_Supported_Writer() )->create_customer( $mobile, '', $mobile, wp_generate_password( 20 ) );
			if ( is_wp_error( $uid ) ) {
				return $this->registration_error( $uid );
			}
			$user = get_user_by( 'id', $uid );
		}
		return cb_response( self::auth_response( $user ), 200 );
	}

	public function forgot_password( WP_REST_Request $request ) {
		$email  = sanitize_email( (string) $request->get_param( 'email' ) );
		$mobile = trim( (string) $request->get_param( 'mobile' ) );
		if ( $email !== '' ) {
			$user = get_user_by( 'email', $email );
			if ( $user && ! wp_using_ext_object_cache() ) {
				// retrieve_password issues the key that WordPress places in its email.
				// Store only a keyed hash of that actual key, never a separate stale key.
				$observer = static function ( $login, $key ) {
					set_transient( 'cb_reset_' . hash( 'sha256', $key ), $login, HOUR_IN_SECONDS );
				};
				add_action( 'retrieve_password_key', $observer, 10, 2 );
				retrieve_password( $user->user_login );
				remove_action( 'retrieve_password_key', $observer, 10 );
			}
		} elseif ( $mobile !== '' ) {
			if ( wp_using_ext_object_cache() ) {
				return cb_error( 'بازیابی با کد تأیید موقتاً در دسترس نیست.', 503, 'OTP_UNAVAILABLE' );
			}
			try {
				$this->issue_otp( $mobile, 'reset' ); // reuse OTP channel for mobile reset
			} catch ( Exception $e ) {
				// To prevent user enumeration or rate limits showing up differently,
				// we just ignore it. But it's better to just proceed and return 200.
			}
		} else {
			return cb_error( 'ایمیل یا موبایل الزامی است.', 400, 'VALIDATION' );
		}
		// Always 200 so we don't leak which accounts exist.
		return cb_response( array( 'sent' => true ), 200 );
	}

	public function reset_password( WP_REST_Request $request ) {
		$token    = (string) $request->get_param( 'token' );
		$password = (string) $request->get_param( 'newPassword' );
		if ( strlen( $password ) < 6 ) {
			return cb_error( 'رمز عبور حداقل ۶ نویسه باشد.', 400, 'WEAK_PASSWORD' );
		}
		$key = 'cb_reset_' . hash( 'sha256', $token );
		$login = get_transient( $key );
		if ( ! is_string( $login ) || $login === '' ) {
			return cb_error( 'توکن نامعتبر یا منقضی است.', 400, 'INVALID_TOKEN' );
		}
		$user = check_password_reset_key( $token, $login );
		if ( is_wp_error( $user ) || ! $user instanceof WP_User || ! ( new CB_Reset_Atomic_Consumer() )->consume( $key, $login ) ) {
			return cb_error( 'توکن نامعتبر یا منقضی است.', 400, 'INVALID_TOKEN' );
		}
		reset_password( $user, $password );
		CB_JWT::revoke_for_user( $user->ID );
		return cb_response( array( 'reset' => true ), 200 );
	}

	public function reset_password_with_otp( WP_REST_Request $request ) {
		$mobile   = trim( (string) $request->get_param( 'mobile' ) );
		$code     = (string) $request->get_param( 'otpCode' );
		$password = (string) $request->get_param( 'newPassword' );
		if ( strlen( $password ) < 6 ) {
			return cb_error( 'رمز عبور حداقل ۶ نویسه باشد.', 400, 'WEAK_PASSWORD' );
		}
		if ( ! $this->verify_otp( $mobile, $code, 'reset' ) ) {
			return cb_error( 'کد تأیید نادرست یا منقضی است.', 401, 'BAD_OTP' );
		}
		$user = self::user_by_mobile( $mobile );
		if ( ! $user ) {
			return cb_error( 'کاربر یافت نشد.', 404, 'USER_NOT_FOUND' );
		}
		reset_password( $user, $password );
		CB_JWT::revoke_for_user( $user->ID );
		return cb_response( array( 'reset' => true ), 200 );
	}

	public function login( WP_REST_Request $request ) {
		$username = trim( (string) $request->get_param( 'username' ) );
		$password = (string) $request->get_param( 'password' );

		if ( $username === '' || $password === '' ) {
			return cb_error( 'نام کاربری و رمز عبور الزامی است.', 400, 'VALIDATION' );
		}

		// Allow login by email, username, or mobile (billing phone / cb_mobile meta).
		$login = self::resolve_login( $username );
		if ( is_wp_error( $login ) ) {
			return cb_error( 'نام کاربری یا رمز عبور نادرست است.', 401, 'BAD_CREDENTIALS' );
		}

		$user = wp_authenticate( $login, $password );
		if ( is_wp_error( $user ) ) {
			return cb_error( 'نام کاربری یا رمز عبور نادرست است.', 401, 'BAD_CREDENTIALS' );
		}

		return cb_response( self::auth_response( $user ), 200 );
	}

	public function register( WP_REST_Request $request ) {
		$raw_email = trim( (string) $request->get_param( 'email' ) );
		$email    = sanitize_email( $raw_email );
		$mobile   = trim( (string) $request->get_param( 'mobile' ) );
		$password = (string) $request->get_param( 'password' );

		if ( $raw_email !== '' && ( ! is_email( $raw_email ) || $email !== $raw_email ) ) {
			return cb_error( 'ایمیل نامعتبر است.', 400, 'INVALID_INPUT' );
		}
		if ( $password === '' || ( $email === '' && $mobile === '' ) ) {
			return cb_error( 'ایمیل یا موبایل به‌همراه رمز عبور الزامی است.', 400, 'VALIDATION' );
		}

		if ( strlen( $password ) < 6 ) {
			return cb_error( 'رمز عبور حداقل ۶ نویسه باشد.', 400, 'WEAK_PASSWORD' );
		}

		$login = $email !== '' ? $email : $mobile;
		$user_id = ( new CB_Identity_Supported_Writer() )->create_customer( $login, $email ?: '', $mobile, $password );
		if ( is_wp_error( $user_id ) ) {
			return $this->registration_error( $user_id );
		}

		return cb_response( self::auth_response( get_user_by( 'id', $user_id ) ), 201 );
	}

	public function refresh( WP_REST_Request $request ) {
		$token   = (string) $request->get_param( 'refreshToken' );
		$payload = CB_JWT::decode( $token );

		if ( ! $payload || ( $payload['typ'] ?? '' ) !== 'refresh' ) {
			return cb_error( 'توکن نامعتبر یا منقضی‌شده است.', 401, 'INVALID_REFRESH_TOKEN' );
		}
		$user = get_user_by( 'id', (int) ( $payload['uid'] ?? 0 ) );
		if ( ! $user ) {
			return cb_error( 'کاربر یافت نشد.', 401, 'USER_NOT_FOUND' );
		}

		return cb_response( array(
			'accessToken'  => CB_JWT::issue( $user, 'access' ),
			'refreshToken' => CB_JWT::issue( $user, 'refresh' ),
		), 200 );
	}

	public function me( WP_REST_Request $request ) {
		$user = CB_Plugin::current_user( $request );
		if ( ! $user ) {
			return cb_error( 'احراز هویت لازم است.', 401, 'UNAUTHORIZED' );
		}
		return cb_response( self::user_response( $user ), 200 );
	}

	// ---- helpers ------------------------------------------------------------

	private static function resolve_login( string $identifier ) {
		$identity = ( new CB_Identity_Supported_Writer() )->lookup( $identifier );
		if ( $identity['status'] === 'CONFLICT' || $identity['status'] === 'UNAVAILABLE' ) {
			return new WP_Error( 'cb_identity_ambiguous', 'Authentication is unavailable.' );
		}
		if ( $identity['status'] === 'UNIQUE' ) {
			$user = get_user_by( 'id', $identity['user_id'] );
			return $user ? $user->user_login : new WP_Error( 'cb_identity_unavailable', 'Authentication is unavailable.' );
		}
		return $identifier;
	}

	private function registration_error( WP_Error $error ) {
		$code = $error->get_error_code();
		if ( $code === 'cb_identity_exists' ) {
			return cb_error( 'این حساب قبلاً ثبت شده است.', 409, 'EMAIL_ALREADY_EXISTS' );
		}
		if ( $code === 'cb_identity_invalid' ) {
			return cb_error( 'اطلاعات ثبت‌نام نامعتبر است.', 400, 'INVALID_INPUT' );
		}
		return cb_error( 'سرویس ثبت‌نام موقتاً در دسترس نیست.', 503, 'UNAVAILABLE' );
	}

	private function identity_status( WP_Error $error ): int {
		return $error->get_error_code() === 'cb_identity_exists' ? 409 : ( $error->get_error_code() === 'cb_identity_invalid' ? 400 : 503 );
	}

	public static function auth_response( WP_User $user ): array {
		return array(
			'accessToken'  => CB_JWT::issue( $user, 'access' ),
			'refreshToken' => CB_JWT::issue( $user, 'refresh' ),
			'user'         => self::user_response( $user ),
		);
	}

	public static function user_response( WP_User $user ): array {
		$postal = get_user_meta( $user->ID, 'cb_postal_code', true );
		return array(
			'id'         => (int) $user->ID,
			'email'      => $user->user_email ?: null,
			'mobile'     => get_user_meta( $user->ID, 'cb_mobile', true ) ?: null,
			'fullName'   => trim( $user->display_name ) ?: null,
			'firstName'  => $user->first_name ?: null,
			'lastName'   => $user->last_name ?: null,
			'phone'      => get_user_meta( $user->ID, 'billing_phone', true ) ?: null,
			'city'       => get_user_meta( $user->ID, 'billing_city', true ) ?: null,
			'postalCode' => $postal !== '' ? (int) $postal : null,
			'role'       => CB_JWT::primary_role( $user ),
			'active'     => true,
		);
	}
}
