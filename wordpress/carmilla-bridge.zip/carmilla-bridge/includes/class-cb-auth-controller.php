<?php
/**
 * Auth endpoints mirroring the Spring AuthController, backed by WordPress users.
 *   POST api/auth/login       { username, password } -> AuthResponse
 *   POST api/auth/register    { email?, mobile?, password } -> AuthResponse
 *   POST api/auth/refresh     { refreshToken } -> RefreshTokenResponse
 *   GET  api/users/me         (Bearer) -> UserResponse
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CB_Auth_Controller {

	public function register_routes(): void {
		$ns = CB_REST_NAMESPACE;

		register_rest_route( $ns, '/api/auth/login', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'login' ),
			'permission_callback' => '__return_true',
		) );

		register_rest_route( $ns, '/api/auth/register', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'register' ),
			'permission_callback' => '__return_true',
		) );

		register_rest_route( $ns, '/api/auth/refresh', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'refresh' ),
			'permission_callback' => '__return_true',
		) );

		// NOTE: GET/PATCH /api/users/me is owned by CB_Account_Controller
		// (ProfileResponse), which is what the app's ProfileApi expects.

		// Password reset + OTP login (all public).
		foreach ( array(
			'forgot-password'          => 'forgot_password',
			'send-login-otp'           => 'send_login_otp',
			'login-with-otp'           => 'login_with_otp',
			'reset-password'           => 'reset_password',
			'reset-password-with-otp'  => 'reset_password_with_otp',
		) as $path => $method ) {
			register_rest_route( $ns, '/api/auth/' . $path, array(
				'methods'             => 'POST',
				'callback'            => array( $this, $method ),
				'permission_callback' => '__return_true',
			) );
		}
	}

	// ---- OTP + password reset ----------------------------------------------

	/** Find a user by their stored mobile (cb_mobile meta or login). */
	private static function user_by_mobile( string $mobile ) {
		$mobile = trim( $mobile );
		if ( $mobile === '' ) {
			return null;
		}
		$users = get_users( array( 'meta_key' => 'cb_mobile', 'meta_value' => $mobile, 'number' => 1 ) );
		if ( ! empty( $users ) ) {
			return $users[0];
		}
		$u = get_user_by( 'login', $mobile );
		return $u ?: null;
	}

	/**
	 * Generate + "send" a 6-digit OTP for a mobile with purpose, cooldown, and hash.
	 */
	private function issue_otp( string $mobile, string $purpose ): string {
		$hash_key = md5( $mobile . '_' . $purpose );

		if ( get_transient( 'cb_otp_cooldown_' . $hash_key ) ) {
			throw new Exception( 'لطفاً یک دقیقه صبر کنید.' );
		}

		$code = (string) wp_rand( 100000, 999999 );
		$hashed = wp_hash_password( $code );

		set_transient( 'cb_otp_' . $hash_key, $hashed, 3 * MINUTE_IN_SECONDS );
		set_transient( 'cb_otp_cooldown_' . $hash_key, '1', MINUTE_IN_SECONDS );
		delete_transient( 'cb_otp_attempts_' . $hash_key );

		// Allow override via filter
		$override = apply_filters( 'cb_send_otp_override', null, $mobile, $code, $purpose );
		if ( $override !== null ) {
			if ( is_wp_error( $override ) ) {
				throw new Exception( $override->get_error_message() );
			}
		} else {
			// Build message using template engine if available
			$template = get_option('carmilla_message_settings', [])['sms_otp_template'] ?? 'کد تایید شما: {{code}}';
			$message = class_exists('CB_Template_Engine') ? CB_Template_Engine::render($template, ['code' => $code]) : "کد تایید شما: $code";
			
			$result = CB_SMS_HTTP_Adapter::send($mobile, $message);
			if ( is_wp_error( $result ) ) {
				// Don't set cooldown if sending failed so they can retry immediately
				delete_transient( 'cb_otp_cooldown_' . $hash_key );
				delete_transient( 'cb_otp_' . $hash_key );
				throw new Exception( 'خطا در ارسال پیامک: ' . $result->get_error_message() );
			}
		}

		do_action( 'cb_send_otp', $mobile, $code, $purpose ); // legacy hook
		return $code;
	}

	private function verify_otp( string $mobile, string $code, string $purpose ): bool {
		$hash_key = md5( $mobile . '_' . $purpose );
		$stored = get_transient( 'cb_otp_' . $hash_key );
		if ( ! $stored ) {
			return false;
		}

		$attempts = (int) get_transient( 'cb_otp_attempts_' . $hash_key );
		if ( $attempts >= 3 ) {
			delete_transient( 'cb_otp_' . $hash_key );
			delete_transient( 'cb_otp_attempts_' . $hash_key );
			return false;
		}

		if ( wp_check_password( trim( $code ), $stored ) ) {
			delete_transient( 'cb_otp_' . $hash_key );
			delete_transient( 'cb_otp_attempts_' . $hash_key );
			return true;
		}

		set_transient( 'cb_otp_attempts_' . $hash_key, $attempts + 1, 3 * MINUTE_IN_SECONDS );
		return false;
	}

	public function send_login_otp( WP_REST_Request $request ) {
		$mobile = trim( (string) $request->get_param( 'mobile' ) );
		if ( $mobile === '' ) {
			return cb_error( 'شماره موبایل الزامی است.', 400, 'VALIDATION' );
		}
		try {
			$this->issue_otp( $mobile, 'login' );
		} catch ( Exception $e ) {
			return cb_error( $e->getMessage(), 429, 'RATE_LIMIT' );
		}
		return cb_response( array( 'sent' => true ), 200 );
	}

	public function login_with_otp( WP_REST_Request $request ) {
		$mobile = trim( (string) $request->get_param( 'mobile' ) );
		$code   = (string) $request->get_param( 'otpCode' );
		if ( ! $this->verify_otp( $mobile, $code, 'login' ) ) {
			return cb_error( 'کد تأیید نادرست یا منقضی است.', 401, 'BAD_OTP' );
		}
		$user = self::user_by_mobile( $mobile );
		if ( ! $user ) {
			// First OTP login registers the mobile-only account.
			$uid = wp_insert_user( array( 'user_login' => $mobile, 'user_pass' => wp_generate_password( 20 ), 'role' => 'customer' ) );
			if ( is_wp_error( $uid ) ) {
				return cb_error( 'ساخت حساب ناموفق بود.', 400, 'REGISTER_FAILED' );
			}
			update_user_meta( $uid, 'cb_mobile', $mobile );
			$user = get_user_by( 'id', $uid );
		}
		return cb_response( self::auth_response( $user ), 200 );
	}

	public function forgot_password( WP_REST_Request $request ) {
		$email  = sanitize_email( (string) $request->get_param( 'email' ) );
		$mobile = trim( (string) $request->get_param( 'mobile' ) );
		if ( $email !== '' ) {
			$user = get_user_by( 'email', $email );
			if ( $user ) {
				// Issue a reset token and email a WP reset link.
				$key = get_password_reset_key( $user );
				if ( ! is_wp_error( $key ) ) {
					set_transient( 'cb_reset_' . $key, $user->ID, HOUR_IN_SECONDS );
					retrieve_password( $user->user_login );
				}
			}
		} elseif ( $mobile !== '' ) {
			try {
				$this->issue_otp( $mobile, 'reset' ); // reuse OTP channel for mobile reset
			} catch ( Exception $e ) {
				// To prevent user enumeration or rate limits showing up differently,
				// we just ignore it. But it's better to just proceed and return 200.
			}
		} else {
			return cb_error( 'ایمیل یا موبایل الزامی است.', 400, 'VALIDATION' );
		}
		// Always 200 so we don't leak which accounts exist.
		return cb_response( array( 'sent' => true ), 200 );
	}

	public function reset_password( WP_REST_Request $request ) {
		$token    = (string) $request->get_param( 'token' );
		$password = (string) $request->get_param( 'newPassword' );
		if ( strlen( $password ) < 6 ) {
			return cb_error( 'رمز عبور حداقل ۶ نویسه باشد.', 400, 'WEAK_PASSWORD' );
		}
		$uid = get_transient( 'cb_reset_' . $token );
		if ( ! $uid ) {
			return cb_error( 'توکن نامعتبر یا منقضی است.', 400, 'INVALID_TOKEN' );
		}
		$user = get_user_by( 'id', (int) $uid );
		if ( ! $user ) {
			return cb_error( 'کاربر یافت نشد.', 404, 'USER_NOT_FOUND' );
		}
		reset_password( $user, $password );
		CB_JWT::revoke_for_user( $user->ID );
		delete_transient( 'cb_reset_' . $token );
		return cb_response( self::auth_response( get_user_by( 'id', $user->ID ) ), 200 );
	}

	public function reset_password_with_otp( WP_REST_Request $request ) {
		$mobile   = trim( (string) $request->get_param( 'mobile' ) );
		$code     = (string) $request->get_param( 'otpCode' );
		$password = (string) $request->get_param( 'newPassword' );
		if ( strlen( $password ) < 6 ) {
			return cb_error( 'رمز عبور حداقل ۶ نویسه باشد.', 400, 'WEAK_PASSWORD' );
		}
		if ( ! $this->verify_otp( $mobile, $code, 'reset' ) ) {
			return cb_error( 'کد تأیید نادرست یا منقضی است.', 401, 'BAD_OTP' );
		}
		$user = self::user_by_mobile( $mobile );
		if ( ! $user ) {
			return cb_error( 'کاربر یافت نشد.', 404, 'USER_NOT_FOUND' );
		}
		reset_password( $user, $password );
		CB_JWT::revoke_for_user( $user->ID );
		return cb_response( self::auth_response( get_user_by( 'id', $user->ID ) ), 200 );
	}

	public function login( WP_REST_Request $request ) {
		$username = trim( (string) $request->get_param( 'username' ) );
		$password = (string) $request->get_param( 'password' );

		if ( $username === '' || $password === '' ) {
			return cb_error( 'نام کاربری و رمز عبور الزامی است.', 400, 'VALIDATION' );
		}

		// Allow login by email, username, or mobile (billing phone / cb_mobile meta).
		$login = self::resolve_login( $username );

		$user = wp_authenticate( $login, $password );
		if ( is_wp_error( $user ) ) {
			return cb_error( 'نام کاربری یا رمز عبور نادرست است.', 401, 'BAD_CREDENTIALS' );
		}

		return cb_response( self::auth_response( $user ), 200 );
	}

	public function register( WP_REST_Request $request ) {
		$email    = sanitize_email( (string) $request->get_param( 'email' ) );
		$mobile   = trim( (string) $request->get_param( 'mobile' ) );
		$password = (string) $request->get_param( 'password' );

		if ( $password === '' || ( $email === '' && $mobile === '' ) ) {
			return cb_error( 'ایمیل یا موبایل به‌همراه رمز عبور الزامی است.', 400, 'VALIDATION' );
		}

		$login = $email !== '' ? $email : $mobile;
		if ( username_exists( $login ) || ( $email && email_exists( $email ) ) ) {
			return cb_error( 'این کاربر قبلاً ثبت شده است.', 409, 'USER_EXISTS' );
		}

		$user_id = wp_insert_user( array(
			'user_login' => $login,
			'user_email' => $email ?: '',
			'user_pass'  => $password,
			'role'       => 'customer',
		) );
		if ( is_wp_error( $user_id ) ) {
			return cb_error( $user_id->get_error_message(), 400, 'REGISTER_FAILED' );
		}
		if ( $mobile !== '' ) {
			update_user_meta( $user_id, 'cb_mobile', $mobile );
		}

		return cb_response( self::auth_response( get_user_by( 'id', $user_id ) ), 201 );
	}

	public function refresh( WP_REST_Request $request ) {
		$token   = (string) $request->get_param( 'refreshToken' );
		$payload = CB_JWT::decode( $token );

		if ( ! $payload || ( $payload['typ'] ?? '' ) !== 'refresh' ) {
			return cb_error( 'توکن نامعتبر یا منقضی‌شده است.', 401, 'INVALID_REFRESH_TOKEN' );
		}
		$user = get_user_by( 'id', (int) ( $payload['uid'] ?? 0 ) );
		if ( ! $user ) {
			return cb_error( 'کاربر یافت نشد.', 401, 'USER_NOT_FOUND' );
		}

		return cb_response( array(
			'accessToken'  => CB_JWT::issue( $user, 'access' ),
			'refreshToken' => CB_JWT::issue( $user, 'refresh' ),
		), 200 );
	}

	public function me( WP_REST_Request $request ) {
		$user = CB_Plugin::current_user( $request );
		if ( ! $user ) {
			return cb_error( 'احراز هویت لازم است.', 401, 'UNAUTHORIZED' );
		}
		return cb_response( self::user_response( $user ), 200 );
	}

	// ---- helpers ------------------------------------------------------------

	private static function resolve_login( string $identifier ): string {
		if ( is_email( $identifier ) ) {
			$u = get_user_by( 'email', $identifier );
			return $u ? $u->user_login : $identifier;
		}
		// Look up by stored mobile meta.
		$users = get_users( array(
			'meta_key'   => 'cb_mobile',
			'meta_value' => $identifier,
			'number'     => 1,
			'fields'     => array( 'user_login' ),
		) );
		if ( ! empty( $users ) ) {
			return $users[0]->user_login;
		}
		return $identifier;
	}

	public static function auth_response( WP_User $user ): array {
		return array(
			'accessToken'  => CB_JWT::issue( $user, 'access' ),
			'refreshToken' => CB_JWT::issue( $user, 'refresh' ),
			'user'         => self::user_response( $user ),
		);
	}

	public static function user_response( WP_User $user ): array {
		$postal = get_user_meta( $user->ID, 'cb_postal_code', true );
		return array(
			'id'         => (int) $user->ID,
			'email'      => $user->user_email ?: null,
			'mobile'     => get_user_meta( $user->ID, 'cb_mobile', true ) ?: null,
			'fullName'   => trim( $user->display_name ) ?: null,
			'firstName'  => $user->first_name ?: null,
			'lastName'   => $user->last_name ?: null,
			'phone'      => get_user_meta( $user->ID, 'billing_phone', true ) ?: null,
			'city'       => get_user_meta( $user->ID, 'billing_city', true ) ?: null,
			'postalCode' => $postal !== '' ? (int) $postal : null,
			'role'       => CB_JWT::primary_role( $user ),
			'active'     => true,
		);
	}
}
