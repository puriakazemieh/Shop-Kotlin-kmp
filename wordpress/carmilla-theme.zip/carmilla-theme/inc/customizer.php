<?php
/**
 * Theme options via the WordPress Customizer:
 *   - Branding: logo (native), brand colors
 *   - Header/Home: header title, hero title + subtitle
 *   - Features: visibility is read from the Bridge manifest (not Theme Mods)
 *
 * Colors are emitted as CSS custom properties that override tokens.css, so the
 * whole design (app-derived) re-skins live — full white-label from the dashboard.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Default brand colors (mirror tokens.css light theme). */
function carmilla_color_defaults() {
	return array(
		'accent'  => '#20305C',
		'accent2' => '#34487E',
		'gold'    => '#B08D57',
		'bg'      => '#F6F5F1',
		'surface' => '#FFFFFF',
		'ink'     => '#192038',
	);
}

/** Legacy labels retained for documentation/backward-compatible customizer UI. */
function carmilla_feature_toggles() {
	return array(
		'shop'       => __( 'فروشگاه (WooCommerce)', 'carmilla' ),
		'blog'       => __( 'مجله / بلاگ', 'carmilla' ),
		'courses'    => __( 'دوره‌ها (آکادمی)', 'carmilla' ),
		'clinic'     => __( 'مشاوره / نوبت‌دهی', 'carmilla' ),
		'psychtests' => __( 'تست‌های روان‌شناسی', 'carmilla' ),
		'stories'    => __( 'استوری‌ها', 'carmilla' ),
	);
}

/**
 * Read the canonical feature policy shared with Carmilla Bridge.
 * Theme Mods are deliberately not consulted: the plugin option is the only
 * runtime source of truth, while these defaults keep Theme-only installs safe.
 */
function carmilla_manifest_features() {
	if ( class_exists( '\Carmilla_Kernel' ) && \Carmilla_Kernel::is_booted() ) {
		return \Carmilla_Kernel::get_active_features();
	}
	$defaults = array(
		'content.blog' => true, 'commerce.core' => true, 'commerce.physical' => true,
		'commerce.digital' => false, 'academy.core' => false, 'academy.quiz' => false,
		'academy.certificate' => false, 'clinic.booking' => false, 'clinic.messaging' => false,
		'psych.tests' => false, 'wallet' => false, 'admin.mobile' => false,
	);
	$configured = get_option( 'cb_manifest_features', array() );
	if ( ! is_array( $configured ) ) {
		$configured = array();
	}
	foreach ( $defaults as $id => $default ) {
		if ( array_key_exists( $id, $configured ) ) {
			$defaults[ $id ] = (bool) $configured[ $id ];
		}
	}
	$dependencies = array(
		'commerce.physical' => array( 'commerce.core' ), 'commerce.digital' => array( 'commerce.core' ),
		'academy.core' => array( 'content.blog' ), 'academy.quiz' => array( 'academy.core' ),
		'academy.certificate' => array( 'academy.core' ), 'clinic.booking' => array( 'content.blog' ),
		'clinic.messaging' => array( 'clinic.booking' ), 'psych.tests' => array( 'content.blog' ),
		'wallet' => array( 'commerce.core' ),
	);
	foreach ( $dependencies as $child => $parents ) {
		foreach ( $parents as $parent ) {
			if ( empty( $defaults[ $parent ] ) ) {
				$defaults[ $child ] = false;
				break;
			}
		}
	}
	return $defaults;
}

/** Whether a theme surface is enabled by the canonical manifest. */
function carmilla_feature_enabled( $slug ) {
	if ( class_exists( '\Carmilla\Theme\ThemeHostAdapter' ) ) {
		return \Carmilla\Theme\ThemeHostAdapter::is_feature_enabled( $slug );
	}
	if ( class_exists( '\Carmilla_Kernel' ) && \Carmilla_Kernel::is_booted() ) {
		return \Carmilla_Kernel::is_feature_active( $slug );
	}
	$map = array(
		'shop'       => 'commerce.core',
		'blog'       => 'content.blog',
		'courses'    => 'academy.core',
		'clinic'     => 'clinic.booking',
		'psychtests' => 'psych.tests',
		// The manifest has no standalone stories flag; stories follow content.
		'stories'    => 'content.blog',
	);
	$id = isset( $map[ $slug ] ) ? $map[ $slug ] : $slug;
	$features = carmilla_manifest_features();
	return ! empty( $features[ $id ] );
}

add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_panel( 'carmilla_panel', array(
		'title'    => __( 'تنظیمات کارمیلا', 'carmilla' ),
		'priority' => 10,
	) );

	// ---- Branding: colors ----
	$wp_customize->add_section( 'carmilla_colors', array(
		'title' => __( 'رنگ‌های برند', 'carmilla' ),
		'panel' => 'carmilla_panel',
	) );
	$labels = array(
		'accent'  => __( 'رنگ اصلی (Accent)', 'carmilla' ),
		'accent2' => __( 'رنگ ثانویه', 'carmilla' ),
		'gold'    => __( 'طلایی', 'carmilla' ),
		'bg'      => __( 'پس‌زمینه', 'carmilla' ),
		'surface' => __( 'سطح کارت', 'carmilla' ),
		'ink'     => __( 'متن اصلی', 'carmilla' ),
	);
	foreach ( carmilla_color_defaults() as $key => $default ) {
		$wp_customize->add_setting( "carmilla_color_$key", array(
			'default'           => $default,
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, "carmilla_color_$key", array(
			'label'   => $labels[ $key ],
			'section' => 'carmilla_colors',
		) ) );
	}

	// ---- Header / Home ----
	$wp_customize->add_section( 'carmilla_header', array(
		'title' => __( 'هدر و صفحه‌ی خانه', 'carmilla' ),
		'panel' => 'carmilla_panel',
	) );
	$texts = array(
		'carmilla_header_title' => array( __( 'عنوان هدر (خالی = نام سایت)', 'carmilla' ), '' ),
		'carmilla_hero_title'   => array( __( 'عنوان هیرو', 'carmilla' ), 'کالکشن پاییز و زمستان' ),
		'carmilla_hero_sub'     => array( __( 'زیرعنوان هیرو', 'carmilla' ), 'جدیدترین محصولات، دوره‌ها و خدمات مشاوره — همه در یک‌جا.' ),
	);
	foreach ( $texts as $id => $conf ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $conf[1],
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $conf[0],
			'section' => 'carmilla_header',
			'type'    => 'text',
		) );
	}

	// ---- Clinic / emergency ----
	$wp_customize->add_section( 'carmilla_clinic', array(
		'title' => __( 'مشاوره و اورژانس', 'carmilla' ),
		'panel' => 'carmilla_panel',
	) );
	$clinic_texts = array(
		'carmilla_emergency_phone' => array( __( 'شماره‌ی تماس اورژانس روانی', 'carmilla' ), '۱۴۸۰' ),
		'carmilla_emergency_note'  => array( __( 'یادداشت اورژانس', 'carmilla' ), 'اگر در وضعیت بحرانی هستید یا افکار آسیب به خود دارید، همین حالا تماس بگیرید.' ),
	);
	foreach ( $clinic_texts as $id => $conf ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $conf[1],
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $conf[0],
			'section' => 'carmilla_clinic',
			'type'    => 'text',
		) );
	}

	// ---- Features ----
	$wp_customize->add_section( 'carmilla_features', array(
		'title'       => __( 'فعال/غیرفعال‌کردن بخش‌ها', 'carmilla' ),
		'description' => __( 'وضعیت بخش‌ها فقط از Carmilla Feature Manifest افزونه خوانده می‌شود؛ Theme Mod قدیمی دیگر منبع حقیقت نیست.', 'carmilla' ),
		'panel'       => 'carmilla_panel',
	) );
} );

/** Boolean sanitizer for checkboxes. */
function carmilla_sanitize_bool( $checked ) {
	return ( isset( $checked ) && true == $checked );
}

/**
 * Emit the Customizer color choices as CSS variables overriding tokens.css.
 */
function carmilla_customizer_css() {
	$d    = carmilla_color_defaults();
	$vars = array(
		'--accent'   => get_theme_mod( 'carmilla_color_accent', $d['accent'] ),
		'--accent-2' => get_theme_mod( 'carmilla_color_accent2', $d['accent2'] ),
		'--gold'     => get_theme_mod( 'carmilla_color_gold', $d['gold'] ),
		'--bg'       => get_theme_mod( 'carmilla_color_bg', $d['bg'] ),
		'--surface'  => get_theme_mod( 'carmilla_color_surface', $d['surface'] ),
		'--ink'      => get_theme_mod( 'carmilla_color_ink', $d['ink'] ),
	);
	// Only emit when at least one differs from default (keeps dark-mode overrides intact otherwise).
	$css = '';
	foreach ( $vars as $name => $val ) {
		if ( $val ) {
			$css .= "$name:$val;";
		}
	}
	if ( $css ) {
		echo "\n<style id=\"carmilla-customizer\">:root{" . esc_html( $css ) . "}</style>\n";
	}
}
add_action( 'wp_head', 'carmilla_customizer_css', 20 );
